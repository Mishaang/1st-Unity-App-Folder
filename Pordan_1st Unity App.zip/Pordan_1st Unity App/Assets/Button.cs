﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Button : MonoBehaviour {

	public GameObject text_1;

	bool Mishang = false;


	public void show_text() 

	{

		if (Mishang == false){

			text_1.SetActive (true);
			Mishang = true;

		}
		else if (Mishang == true){

			text_1.SetActive (false);
			Mishang = false;

		}

	}

	public void QuitApp()
	{
		Application.Quit();
		Debug.Log("Quit");
	}
}